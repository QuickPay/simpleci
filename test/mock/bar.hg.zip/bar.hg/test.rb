puts "This is supposed to simulate a test passed as the exit status will be 0"
exit 0