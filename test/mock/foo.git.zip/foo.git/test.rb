puts "This is supposed to simulate a test failure as the exit status will be 1"
exit 1